﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class IndexOutOfRangeException : Exception
    {
        public void Message()
        {
            Console.WriteLine("Error");
        }
    }
    public class IntegerList : IIntegerList
    {
        private int[]  _internalStorage;
        private int size; 

        public IntegerList()
        {
            _internalStorage = new int[4];
            size = 4;
            for (int i = 0; i < 4; ++i) _internalStorage[i] = 0; 
        }

        public IntegerList(int initialSize)
        {
            if (initialSize <= 0)
            {
                _internalStorage = new int[4];
                for (int i = 0; i < 4; ++i) _internalStorage[i] = 0;
            }
            else
            {
                _internalStorage = new int[initialSize];
                size = initialSize;
                for (int i = 0; i < initialSize; ++i) _internalStorage[i] = 0;
            }
        }

      
        public int Count
        {
            get
            {
                int counter = -1; 
                for(int i = 0; i < _internalStorage.Length; ++i)
                {
                     
                    if(_internalStorage[i] != 0)
                    {
                        counter++; 
                    }
                }
                return counter + 1; 
            }
        }

        public void Add(int item)
        {
            if((Count+1) >= (_internalStorage.Length))
            {
                Array.Resize(ref _internalStorage, (size*2));
            }
            _internalStorage[Count] = item;
            size = _internalStorage.Length; 
        }

        public void Clear()
        {
            for (int i = 0; i < size; ++i)
            {
                _internalStorage[i] = 0;
            }
        }
        public bool Contains(int item)
        {
           for(int i = 0; i < Count; ++i)
            {
                if (_internalStorage[i] == item) return true; 
            }
            return false; 
        }

        public int GetElement(int index)
        {
            if(index < (Count - 1))
            {
                return _internalStorage[index]; 
            }
            else
            {
                throw new IndexOutOfRangeException(); 
            }
        }

        public int IndexOf(int item)
        {
            for(int i = 0; i < Count; ++i)
            {
                if (_internalStorage[i] == item) return i; 
            }
            return -1; 
        }

        public bool Remove(int item)
        {
            
            for(int  i = 0; i < Count; ++i)
            {
                if(_internalStorage[i] == item)
                {
                    return RemoveAt(i);
                }
            }

            return false;
        }

        public bool RemoveAt(int index)
        {
            if(index > (Count - 1))
            {
                return false; 
            }
            else if(index == (Count-1))
            {
                _internalStorage[index] = 0;
                
                return true; 
            }
            else
            {
                int i = index; 
                for(i = (index); i <= (Count-2); ++i)
                {
                    _internalStorage[i] = _internalStorage[i + 1]; 
                }
                for (i = i; i < _internalStorage.Length; ++i)
                {
                    _internalStorage[i] = 0;
                }
                return true; 
            }
        }
    }
    
    
}

